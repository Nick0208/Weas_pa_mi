public class Polinomio {
    public static double evaluar(double[] coef, double x) {
        double resultado = 0;
        int grado = coef.length - 1;
        for (int i = 0; i <= grado; i++) {
            resultado += coef[i] * Math.pow(x, grado - i);
        }
        return resultado;
    }

    public static Double buscarRaiz(double[] coef, double x0, double x1) {
        double f0 = evaluar(coef, x0);
        double f1 = evaluar(coef, x1);
        if (f0 * f1 > 0) return null;

        for (int i = 0; i < 100; i++) {
            double xm = (x0 + x1) / 2;
            double fm = evaluar(coef, xm);

            if (Math.abs(fm) < 1e-6) return xm;

            if (f0 * fm < 0) {
                x1 = xm;
                f1 = fm;
            } else {
                x0 = xm;
                f0 = fm;
            }
        }

        return (x0 + x1) / 2;
    }
}