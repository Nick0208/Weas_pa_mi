import java.util.Scanner;

public class CalculadoraLineal {
    public static void resolver(Scanner sc) {
        System.out.println("Forma: ax + b = 0");
        System.out.print("a: ");
        double a = sc.nextDouble();
        System.out.print("b: ");
        double b = sc.nextDouble();

        if (a == 0) {
            System.out.println("No es una función lineal válida.");
        } else {
            double x = -b / a;
            System.out.println("Raíz: x = " + x);
        }
    }
}