import java.util.Scanner;

public class ControladorPolinomios {
    public static void iniciar() {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== Teorema Fundamental del Álgebra ===");
        System.out.println("Seleccione el tipo de función:");
        System.out.println("1. Función lineal");
        System.out.println("2. Función cuadrática");
        System.out.println("3. Función cúbica");
        System.out.println("4. Función de orden 4");
        System.out.print("Opción: ");
        int opcion = sc.nextInt();

        switch (opcion) {
            case 1:
                CalculadoraLineal.resolver(sc);
                break;
            case 2:
                CalculadoraCuadratica.resolver(sc);
                break;
            case 3:
                CalculadoraCubica.resolver(sc);
                break;
            case 4:
                CalculadoraOrden4.resolver(sc);
                break;
            default:
                System.out.println("Opción no válida.");
        }

        sc.close();
    }
}