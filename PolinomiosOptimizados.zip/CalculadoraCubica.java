import java.util.Scanner;

public class CalculadoraCubica {
    public static void resolver(Scanner sc) {
        System.out.println("Forma: ax^3 + bx^2 + cx + d = 0");
        System.out.print("a: ");
        double a = sc.nextDouble();
        System.out.print("b: ");
        double b = sc.nextDouble();
        System.out.print("c: ");
        double c = sc.nextDouble();
        System.out.print("d: ");
        double d = sc.nextDouble();

        if (a == 0) {
            System.out.println("No es cúbica válida.");
            return;
        }

        double[] coef = { a, b, c, d };
        Double raiz = Polinomio.buscarRaiz(coef, -100, 100);

        if (raiz == null) {
            System.out.println("No se encontró una raíz real en [-100, 100].");
        } else {
            System.out.printf("Raíz real aproximada: x ≈ %.6f\n", raiz);
        }
    }
}