import java.util.Scanner;

public class CalculadoraOrden4 {
    public static void resolver(Scanner sc) {
        System.out.println("Forma: ax^4 + bx^3 + cx^2 + dx + e = 0");
        System.out.print("a: ");
        double a = sc.nextDouble();
        System.out.print("b: ");
        double b = sc.nextDouble();
        System.out.print("c: ");
        double c = sc.nextDouble();
        System.out.print("d: ");
        double d = sc.nextDouble();
        System.out.print("e: ");
        double e = sc.nextDouble();

        if (a == 0) {
            System.out.println("No es una ecuación de cuarto grado válida.");
            return;
        }

        double[] coef = { a, b, c, d, e };
        Double raiz = Polinomio.buscarRaiz(coef, -100, 100);

        if (raiz == null) {
            System.out.println("No se encontró una raíz real en [-100, 100].");
        } else {
            System.out.printf("Raíz real aproximada: x ≈ %.6f\n", raiz);
        }
    }
}