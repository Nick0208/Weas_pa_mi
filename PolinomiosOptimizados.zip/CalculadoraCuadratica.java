import java.util.Scanner;

public class CalculadoraCuadratica {
    public static void resolver(Scanner sc) {
        System.out.println("Forma: ax^2 + bx + c = 0");
        System.out.print("a: ");
        double a = sc.nextDouble();
        System.out.print("b: ");
        double b = sc.nextDouble();
        System.out.print("c: ");
        double c = sc.nextDouble();

        if (a == 0) {
            System.out.println("No es cuadrática válida.");
            return;
        }

        double d = b * b - 4 * a * c;

        if (d > 0) {
            double x1 = (-b + Math.sqrt(d)) / (2 * a);
            double x2 = (-b - Math.sqrt(d)) / (2 * a);
            System.out.println("Raíces reales: x1 = " + x1 + ", x2 = " + x2);
        } else if (d == 0) {
            double x = -b / (2 * a);
            System.out.println("Raíz doble: x = " + x);
        } else {
            double real = -b / (2 * a);
            double imag = Math.sqrt(-d) / (2 * a);
            System.out.println("Raíces complejas:");
            System.out.println("x1 = " + real + " + " + imag + "i");
            System.out.println("x2 = " + real + " - " + imag + "i");
        }
    }
}